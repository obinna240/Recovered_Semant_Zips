﻿//used for live editing to invoke no conflict after jquery has loaded with lazy loading
//alert("jquery.noConflict: " + jQuery.noConflict);
jQuery.noConflict();