/*$(function() {
  $('a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
  
 });*/

$(document).ready(function() {
	 	
		$('.click_scroll').click(function(){
			var thisId = $(this).attr('divto');
			$(".dr-nav-fixed").addClass("darkHeader");
			$('html, body').animate({
				scrollTop: $("#"+thisId).offset().top
			}, 1000);	
		})
		
		
		/*$('#searchName').click(function() {
		   $(".dr-nav-fixed").addClass("darkHeader");
		   $.scrollTo($('#first_section'), 5000);
		});
		$('#searchSuggest').click(function() {
		   $(".dr-nav-fixed").addClass("darkHeader");
		   $.scrollTo($('#second_section'), 5000);
		});
		$('#searchResult').click(function() {
		   $(".dr-nav-fixed").addClass("darkHeader");		
		   //$.scrollTo($('#third_section'), 5000);
		   $('html, body').animate({
				scrollTop: $("#third_section").offset().top
			}, 2000);
		});*/


	 
        $('#show-me')
          .css('display', 'block')
          .animate({opacity: 1.0, left: '0px'}, 2000);
		  
		  $('#show-me2')
          .css('display', 'block')
          .animate({opacity: 1.0, right: '0px'}, 2000);
		  
		  
	$(".button").click(function(){
        $(".toggle").toggle();
		if($('.minus').css('display') == 'none'){
			$('.minus').  css('display','block');
			$('.plus').css('display','none');
			}
			else {
				 $('.minus').css('display','none');
			$('.plus').css('display','block  ');
			}
		 
    });
	 var scroll = $(window).scrollTop();
	 if (scroll >= 63) {
	  $(".dr-nav-fixed").addClass("darkHeader");
	 } else {
	  $(".dr-nav-fixed").removeClass("darkHeader");
	 }
		  
});
	


$(window).scroll(function() {  
  var scroll = $(window).scrollTop();

  if (scroll >= 63) {
	  $(".dr-nav-fixed").addClass("darkHeader");
  } else {
	  $(".dr-nav-fixed").removeClass("darkHeader");
  }
});	
		  
	
		  
		  
		 

	  


 

